﻿/*
 * Devjeet Roy
 * Student ID: 11404808
 * 
 * */
using System;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace CS_422
{
	class WebServer
	{
		private const string STUDENT_ID = "11404808";
		private const string CRLF = @"\r\n";
		private const string DEFAULT_TEMPLATE =
			"HTTP/1.1 200 OK\r\n" +
			"Content-Type: text/html\r\n" +
			"\r\n\r\n" +
			"<html>ID Number: {0}<br>" +
			"DateTime.Now: {1}<br>" +
			"Requested URL: {2}</html>";
		private const string URL_REGEX_PATTERN = @"(\/.*).*";
		private const string HTTP_VERSION = "HTTP/1.1";
		private const string HEADER_REGEX_PATTERN = @".*:.*";
		private const String GET_REQUEST_STRING = "GET";

		public static bool Start(int port, string responseTemplate)
		{
			try{
				TcpListener listener = new TcpListener (System.Net.IPAddress.Any, port);

				listener.Start ();

				TcpClient client = listener.AcceptTcpClient ();
				List<byte> bufferedRequest = new List<byte>();

				while(true){
					
					NetworkStream networkStream = client.GetStream ();

					int available = client.Available;

					while(client.Available > 0)
					{ 
						byte[] buf = new byte[client.Available];

						networkStream.Read(buf,0,client.Available);
						bufferedRequest.AddRange(buf);

						String request  = System.Text.ASCIIEncoding.UTF8.GetString(bufferedRequest.ToArray());

						if(!isValidRequest(bufferedRequest)){
							client.Close ();
							listener.Stop ();

							return false;
						}

						if(request.Length >= 4 && request.Contains(CRLF + CRLF)){
							String url = request.Split(' ')[1];

							byte[] responseBytes = Encoding.ASCII.GetBytes(string.Format(responseTemplate, STUDENT_ID,
								DateTime.Now, url));
							
							networkStream.Write(responseBytes, 0, responseBytes.Length);
							client.Close ();
							listener.Stop ();

							return true;
						}
					}
				}
			}
			catch(SocketException e) {
				Console.WriteLine ("SocketException: {0}", e);
			}
			return true;
		}

		private static bool isValidRequest(List<byte> requestBytes){

			String request = System.Text.ASCIIEncoding.UTF8.GetString (requestBytes.ToArray());
			Console.WriteLine (request);
			String[] requestLines = request.Split(new String[] { CRLF}, 
												StringSplitOptions.None);
			
			// process first line for request
			if (requestLines.Length >= 1) {
				if (!processFirstLine (requestLines [0]))
					return false;
			}

			// process headers
			if (requestLines.Length >= 2) {
			
				for(int i = 1; i < requestLines.Length; i++){
				
					if(requestLines[i]  != ""){
						Regex r = new Regex(HEADER_REGEX_PATTERN);

						if ((!r.IsMatch (requestLines [i])) && 
							(i < requestLines.Length - 1 
								&& requestLines[i+1] == "")) {
							return false;
						}
					}	
				}
			}

			return true;
		}


		private static bool processFirstLine(String line){

			String[] tokens = line.Trim().Split (new char[]{ ' ' }, StringSplitOptions.None);


			if (tokens.Length > 3) {
				return false;
			}

			if (!GET_REQUEST_STRING.Contains (tokens [0]))
				return false;

			if (tokens.Length == 2) {
				Regex r = new Regex (URL_REGEX_PATTERN);

				if (!r.IsMatch (tokens [1]))
					return false;
			}

			if (tokens.Length == 3) {
				if (!HTTP_VERSION.Contains (tokens [2]))
					return false;
				
			}

			return true;
		}
	}
}
	

